// Initialize an empty cart
let cart = [];

// Function to add products to the cart
function addToCart(productName, productPrice) {
    // Check if product already exists in cart
    const existingProduct = cart.find(item => item.name === productName);

    if (existingProduct) {
        // If product exists, increase the quantity
        existingProduct.quantity += 1;
    } else {
        // If it's a new product, add it to cart
        cart.push({
            name: productName,
            price: productPrice,
            quantity: 1
        });
    }

    // Update the cart count
    updateCartCount();

    // Optionally, you can log the cart for debugging purposes
    console.log(cart);
}

// Function to update the cart item count in the navbar
function updateCartCount() {
    const cartCount = document.getElementById('cart-count');
    const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
    cartCount.textContent = totalItems;
}

// You can add a function to display the cart items on the cart page
function displayCart() {
    const cartContainer = document.getElementById('cart-items');
    cartContainer.innerHTML = '';

    cart.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');
        cartItem.innerHTML = `
            <p>${item.name}</p>
            <p>₹${item.price} x ${item.quantity}</p>
            <button onclick="removeFromCart('${item.name}')">Remove</button>
        `;
        cartContainer.appendChild(cartItem);
    });
}

// Function to remove items from the cart
function removeFromCart(productName) {
    const productIndex = cart.findIndex(item => item.name === productName);
    if (productIndex > -1) {
        cart.splice(productIndex, 1);
    }

    displayCart();
    updateCartCount();
}

// You can call `displayCart()` on the cart page to show the items in the cart
