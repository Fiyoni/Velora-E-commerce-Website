    window.addEventListener("load", () => {
        setTimeout(() => {
            // Hide intro screen
            document.getElementById("intro").style.display = "none";

            // Show navbar
            document.querySelector(".navbar").style.display = "flex";

            // Show and animate main content
            const main = document.getElementById("main-content");
            main.style.display = "block";
            setTimeout(() => {
                main.classList.add("show");
            }, 100); // Trigger fade-in smoothly
        }, 3000); // Wait for 3 seconds
    });

    // Like button toggle
document.addEventListener('DOMContentLoaded', function () {
    const likeButtons = document.querySelectorAll('.like-btn');

    likeButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            btn.classList.toggle('liked');

            const icon = btn.querySelector('i');
            if (btn.classList.contains('liked')) {
                icon.classList.remove('fa-regular');
                icon.classList.add('fa-solid');
                // Optionally: Save liked product to cart or wishlist
                // addToCart(productId); 
            } else {
                icon.classList.remove('fa-solid');
                icon.classList.add('fa-regular');
                // Optionally: Remove from cart or wishlist
            }
        });
    });
});
